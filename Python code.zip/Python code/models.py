class Brand:
    def __init__(self, json_data):
        try:
            self.brandId = json_data["_id"]["$oid"]
        except KeyError:
            self.brandId = None

        try:
            self.barcode = json_data["barcode"]
        except KeyError:
            self.barcode = None

        try:
            self.brandCode = json_data["brandCode"]
        except KeyError:
            self.brandCode = None

        try:
            self.category = json_data["category"]
        except KeyError:
            self.category = None

        try:
            self.categoryCode = json_data["categoryCode"]
        except KeyError:
            self.categoryCode = None

        try:
            self.cpg_id = json_data["cpg"]["$id"]["$oid"]
        except KeyError:
            self.cpg_id = None

        try:
            self.cpg_ref = json_data["cpg"]["$ref"]
        except KeyError:
            self.cpg_ref = None

        try:
            self.name = json_data["name"]
        except KeyError:
            self.name = None

        try:
            self.topBrand = json_data["topBrand"]
        except KeyError:
            self.topBrand = None