brand_create_table_query = '''
CREATE TABLE IF NOT EXISTS brands (
    brandId VARCHAR(255) PRIMARY KEY,
    barcode VARCHAR(255),
    brandCode VARCHAR(255),
    category VARCHAR(255),
    categoryCode VARCHAR(255),
    cpg_id VARCHAR(255),
    cpg_ref VARCHAR(255),
    name VARCHAR(255),
    topBrand BOOLEAN
)
'''
brand_insert_query = '''
        INSERT INTO brands (
            brandId,
            barcode,
            brandCode,
            category,
            categoryCode,
            cpg_id,
            cpg_ref,
            name,
            topBrand
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s
        )
        '''